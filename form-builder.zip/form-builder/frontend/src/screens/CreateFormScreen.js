import React, { useState } from 'react';
import { View, TextInput, Button, FlatList, StyleSheet } from 'react-native';
import { createForm } from '../services/api';
import QuestionItem from '../components/QuestionItem';

const CreateFormScreen = () => {
  const [formTitle, setFormTitle] = useState('');
  const [questions, setQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState('');

  const addQuestion = () => {
    setQuestions([...questions, { type: 'Text', text: currentQuestion }]);
    setCurrentQuestion('');
  };

  const saveForm = async () => {
    const formData = { title: formTitle, questions };
    await createForm(formData);
  };

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Form Title"
        value={formTitle}
        onChangeText={setFormTitle}
        style={styles.input}
      />
      <TextInput
        placeholder="Question Text"
        value={currentQuestion}
        onChangeText={setCurrentQuestion}
        style={styles.input}
      />
      <Button title="Add Question" onPress={addQuestion} />
      <FlatList
        data={questions}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => <QuestionItem question={item} />}
      />
      <Button title="Save Form" onPress={saveForm} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { padding: 20 },
  input: { borderWidth: 1, marginBottom: 10, padding: 10 },
});

export default CreateFormScreen;
