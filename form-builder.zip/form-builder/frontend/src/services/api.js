import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api/forms';

export const createForm = (formData) => axios.post(API_BASE_URL, formData);
export const getForms = () => axios.get(API_BASE_URL);
export const submitFormResponse = (formId, response) =>
  axios.post(`${API_BASE_URL}/${formId}/response`, response);
