const mongoose = require('mongoose');

const QuestionSchema = new mongoose.Schema({
  type: String,
  text: String,
  options: [String],
  image: String,
});

const FormSchema = new mongoose.Schema({
  title: String,
  headerImage: String,
  questions: [QuestionSchema],
  responses: [Object],
});

module.exports = mongoose.model('Form', FormSchema);
