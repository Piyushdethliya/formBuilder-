const express = require('express');
const Form = require('../models/Form');

const router = express.Router();

// Create a form
router.post('/', async (req, res) => {
  try {
    const form = new Form(req.body);
    await form.save();
    res.status(201).json(form);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all forms
router.get('/', async (req, res) => {
  try {
    const forms = await Form.find();
    res.status(200).json(forms);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Submit form response
router.post('/:id/response', async (req, res) => {
  try {
    const form = await Form.findById(req.params.id);
    form.responses.push(req.body);
    await form.save();
    res.status(200).json(form);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
